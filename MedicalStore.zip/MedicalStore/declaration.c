#include <stdio.h>
#include <time.h>
#include "headerFile.h"

void menu()
 {
 	char choice = 0;


	printf("\n\n\t\t\t\t*************************************************\n");
	printf("\t\t\t\t*                                               *\n");
	printf("\t\t\t\t* MADNI SUBHANALLAH Medical Inventory and Store *\n");
	printf("\t\t\t\t*                                               *\n");
	printf("\t\t\t\t*************************************************\n");
 	printf("\n\n");
 	printf("\t\t\t\t a)List of medicine\n\n");
 	printf("\t\t\t\t b)Add medicine\n\n");
 	printf("\t\t\t\t c)Edit medicine\n\n");
 	printf("\t\t\t\t d)Search medicine\n\n");
 	printf("\t\t\t\t e)Delete medicine\n\n");
 	printf("\t\t\t\t f)Billing\n\n");
 	time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    char s[64];
    strftime(s, sizeof(s), "%c", tm);
    printf("\t\t\t\tDATE AND TIME : %s\n\n\n", s);
 	printf("\t\t\t\t Press any key for Exit\n\n\n");




    printf("\t\t\t\tEnter choice : ");
    scanf(" %c",&choice);
    char *ptr=&choice;

   if(*ptr == 'a')
    {
    	listOfMedicine();
    }
    else if(*ptr == 'b')
    {
    	addMedicine();
    }
	else if(*ptr == 'c')
    {
    	editMedicine();
    }
	else if(*ptr == 'd')
    {
    	searchMedicine();
    }
    else if(*ptr == 'e')
	{
		deleteMedicine();
	}
	else if(*ptr == 'f')
    {
    	generateBill();
    }
    else
    {
    	system("cls");
    	main();
	}
}

void listOfMedicine()
{

	int choice = 0;
 	int code =0;
    int price = 0;

    char expiryDate[15];
    int quantity = 0;
    int discount = 0;

    char name[15];
    char company[20];

	system("cls");
	FILE *fptr;

	fptr = fopen("listofmedicine.txt","r");

	printf("\n\n\t\t\t\t\t********************************\n");
	printf("\t\t\t\t\t*       LIST OF MEDICINE       *\n");
	printf("\t\t\t\t\t********************************\n");
 	printf("\n\n");
	printf("|CODE|\t\t  |Item Name|\t\t     |Medicine Company|\t\t   |Quantity|\t|Price|\t\t|Expiry Date|");
	printf("\n---------------------------------------------------------------------------------------------------------------------");
	printf("\n");
	if(fptr == NULL)
	{
		printf("Error: can not open the file");
		return 0;
	}
	while(fscanf(fptr,"%d %s %s %d %d %s ",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
        printf("\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
	}

	fclose(fptr);

	printf("\n\n\n\t\tIF you want to go back press B or press any key for exit E:");
	scanf(" %c",&choice);
	if(choice == 'B'||choice == 'b')
	{
		system("cls");
		 menu();
	}
	else
	{
		system("cls");
		main();
	}

}

void addMedicine()
{
	system("cls");

	int choice = 0;
	int valid = 0;
 	int code =0;
    int price = 0;
    int code1;
    int price1 = 0;
    char expiryDate[15];
    int quantity = 0;
    char expiryDate1[15];
    int quantity1 = 0;
    char name[15];
    char name1[15];
    char company[20];
    char company1[20];
    int res = 0;

	FILE *fptr;

	fptr = fopen("listofmedicine.txt","r+");
	printf("\n\n\t\t\t\t\t********************************\n");
	printf("\t\t\t\t\t*       ADD MEDICINE\t       *\n");
	printf("\t\t\t\t\t********************************\n");
	printf("\n\n\t\t\t\t\tItem code : ");

	while(1){
        getchar();
        scanf("%d",&code1);
        if(code1>=0&&code1<=9999){
            break;
        }
        else{
            printf("\n\n\t\t\t\t\tItem Code must be a number. Input again: ");


        }
	}

	printf("\n\t\t\t\t\tMedicine Name : ");
	scanf(" %s",name1);
	printf("\n\t\t\t\t\tMedicine Company : ");
	scanf(" %s",company1);
	printf("\n\t\t\t\t\tQuantity: ");
	scanf(" %d",&quantity1);
	printf("\n\t\t\t\t\tPrice:");
	scanf(" %d",&price1);
	printf("\n\t\t\t\t\tExpiry date :");
	scanf(" %s",expiryDate1);

    while(fscanf(fptr,"%d %s %s %d %d %s ",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
		res=strcmp(name,name1);

		if((res==0) || (code==code1))
		{
		    valid =1;
		}

	}
	if(valid==1)
    {
        printf("\n\n\t\t\t\t\tThis medicine code or medicine name  has already added");
    }
    else{
        fprintf(fptr,"\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code1,name1,company1,quantity1,price1,expiryDate1);
            printf("\n\n\t\t\t\t\tYour Medicine Has Been Added");
    }



        fclose(fptr);

        printf("\n\n\tIf you want to add more medicine press Y or want to go back to menu press B or press any key to exit : ");
        scanf(" %c",&choice);
        if(choice == 'Y'  || choice == 'y')
        {
            system("cls");
            addMedicine();
        }
        else if(choice == 'B' ||choice == 'b')
        {
            system("cls");
             menu();
        }
        else
        {
            system("cls");
            main();
        }

}
void editMedicine()
{


	int choice1 = 0;
	int choice = 0;
 	int code =0;
	int price = 0;
	char itemName[15];
	char expiryDate[15];
	int quantity = 0;
	char name[15];
	char company[20];

	system("cls");
	FILE *fptr;
	FILE *fptr1;
	int res,valid=0;
	char name1[20];
	int price1 = 0;

	fptr =fopen("listOfMedicine.txt","r");
	fptr1 =fopen("temp.txt","a");
	printf("\n\n\t\t\t\t\t********************************\n");
	printf("\t\t\t\t\t*       EDIT MEDICINE\t       *\n");
	printf("\t\t\t\t\t********************************\n");
	printf("\n\t\t\t\t\tEnter medicine name : ");
	scanf("%s",name1);

	while(fscanf(fptr,"%d %s %s %d %d %s ",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
		res=strcmp(name,name1);
		if(res==0)
		{
			valid = 1;
			printf("\n\n|CODE|\t\t  |Item Name|\t\t     |Medicine Company|\t\t   |Quantity|\t|Price|\t\t|Expiry Date|");
			printf("\n---------------------------------------------------------------------------------------------------------------------");
			printf("\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
			printf("\n---------------------------------------------------------------------------------------------------------------------");
			printf("\n\n\t\t\t\t\tWhich option do you wish to edit?");
			printf("\n\n\t\t\t\t\t1)price");
			printf("\n\t\t\t\t\t2)Quantity");

			printf("\n\n\t\t\t\t\tEnter your choice:");
			scanf("%d",&choice);
			printf("\n---------------------------------------------------------------------------------------------------------------------");
			if(choice == 1)
			{

                printf("\n\t\t\t\t\tEnter new price : ");
    			scanf("%d",&price1);
    			fprintf(fptr1,"\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price1,expiryDate);
    			printf("\n\n\t\t\t\t\tYour medicine has been updated");
    		}
    		else if(choice == 2)
    		{
    			int quantity1 = 0;
    			printf("\n\t\t\t\t\tEnter new quantity : ");
    			scanf("%d",&quantity1);
    			fprintf(fptr1,"\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity1,price,expiryDate);
    			printf("\n\n\t\t\t\t\tYour medicine has been updated");
    		}


		}
		else
		{
			fprintf(fptr1,"\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
		}
	}
	if(valid==0)
	{
		printf("\n\n\t\t\t\t\t\tMedicine Not found");
	}
	fclose(fptr);
	fclose(fptr1);

	fptr=fopen("listOfMedicine.txt","w");
    fptr1=fopen("temp.txt","r");
	while(fscanf(fptr1,"%d %s %s %d %d %s\n",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
		fprintf(fptr,"\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
	}
	fclose(fptr);
	fclose(fptr1);

	remove("temp.txt");

	printf("\n\n\tIF you want to edit more medicine press Y or want to go back to menu press B or press any key to exit : ");
	scanf(" %c",&choice1);
	if(choice1 == 'Y'  || choice1 == 'y')
	{
		system("cls");
		editMedicine();
	}
	else if(choice1 == 'B' ||choice1 == 'b')
	{
		system("cls");
		 menu();
	}
	else
	{
		system("cls");
		main();
	}
}

void searchMedicine()
{
	system("cls");
	int choice = 0;
 	int code =0;
    int price = 0;
    char itemName[15];
    char expiryDate[15];
    int quantity = 0;
    char name[15];
    char company[20];
	FILE *fptr;

	int res,valid=0;
	char name1[20];

	fptr =fopen("listOfMedicine.txt","r");

	printf("\n\n\t\t\t\t\t********************************\n");
	printf("\t\t\t\t\t*       SEARCH MEDICINE\t       *\n");
	printf("\t\t\t\t\t********************************\n");
	printf("\n\t\t\t\t\tEnter medicine name : ");
	scanf("%s",name1);
	while(fscanf(fptr,"%d %s %s %d %d %s ",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
		res=strcmp(name,name1);
		if(res==0)
		{
			valid = 1;
			printf("\n\n|CODE|\t\t  |Item Name|\t\t     |Medicine Company|\t\t   |Quantity|\t|Price|\t\t|Expiry Date|");
			printf("\n---------------------------------------------------------------------------------------------------------------------");
			printf("\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
			printf("\n---------------------------------------------------------------------------------------------------------------------");
		}

	}
	if(valid == 0)
	{
		printf("\n\n\t\t\t\t\t Medicine Not Found");
	}
	fclose(fptr);

	printf("\n\n\tIF you want to search more medicine press Y or want to go back to menu press B or press any key to exit : ");
	scanf(" %c",&choice);
	if(choice == 'Y'  || choice == 'y')
	{
		system("cls");
		searchMedicine();
	}
	else if(choice == 'B' ||choice == 'b')
	{
		system("cls");
		 menu();
	}
	else
	{
		system("cls");
		main();
	}
}
void deleteMedicine()
{
	system("cls");
	int choice = 0;
	char choice1 = 0;
 	int code =0;
	int price = 0;
	char expiryDate[15];
	int quantity = 0;
	char name[15];
	char company[20];


	FILE *fptr;
	FILE *fptr1;
	int res,valid=0;
	char name1[20];
	int price1 = 0;

	fptr =fopen("listOfMedicine.txt","r");
	fptr1 =fopen("temp.txt","a");
	printf("\n\n\t\t\t\t\t********************************\n");
	printf("\t\t\t\t\t*       DELETE MEDICINE\t       *\n");
	printf("\t\t\t\t\t********************************\n");
	printf("\n\t\t\t\tEnter medicine name you want to delete: ");
	scanf("%s",name1);

	while(fscanf(fptr,"%d %s %s %d %d %s ",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
		res=strcmp(name,name1);
		if(res==0)
		{
			valid = 1;
			printf("\n\n|CODE|\t\t  |Item Name|\t\t     |Medicine Company|\t\t   |Quantity|\t|Price|\t\t|Expiry Date|");
			printf("\n---------------------------------------------------------------------------------------------------------------------");
			printf("\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
			printf("\n---------------------------------------------------------------------------------------------------------------------");
			do
			{

				printf("\n\n   \t\t\t\tAre You sure you want to delete?(y/n) :");
				scanf(" %c",&choice1);
			}
			while(choice1 != 'Y' && choice1!='y' && choice1 !='N' && choice1!='n');
			{
				if(choice1 == 'Y' || choice1 == 'y')
				{
					printf("\n\n\n\t\t\t\t\tRecord has been deleted");
				}
				else
				{
					fprintf(fptr1,"\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
				}
			}
		}
		else
		{
			fprintf(fptr1,"\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
		}
	}
	if(valid==0)
	{
		printf("\n\n\t\t\t\t\tMedicine not found");
	}
	fclose(fptr);
	fclose(fptr1);

	fptr=fopen("listOfMedicine.txt","w");
	fptr1=fopen("temp.txt","r");
	while(fscanf(fptr1,"%d %s %s %d %d %s\n",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
		fprintf(fptr,"\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
	}
	fclose(fptr);
	fclose(fptr1);

	remove("temp.txt");
	printf("\n\n---------------------------------------------------------------------------------------------------------------------");
	printf("\n\n\tIF you want to delete more medicine press Y or want to go back to menu press B or press any key to exit : ");
	scanf(" %c",&choice);
	if(choice == 'Y'  || choice == 'y')
	{
		system("cls");
		deleteMedicine();
	}
	else if(choice == 'B' ||choice == 'b')
	{
		system("cls");
		 menu();
	}
	else
	{
		system("cls");
		main();
	}
}
void generateBill()
{
    char ch;
	system("cls");
	int choice = 0;
 	int code =0;
	int price = 0;
	char itemName[15];
	char expiryDate[15];
	int quantity = 0;
	int discount = 0;
	int amount = 0;
	float originalPrice = 0;

	char company[20];
	int tempPrice=0;
	int code1 = 0;
	char name[20];
	int quantity1 = 0;
	int quantity2=0;
	FILE *fptr;
	FILE *fptr1;
	FILE *fptr2;
	int res,valid=0;
	char name1[20];
	int price1 = 0;

	fptr =fopen("listOfMedicine.txt","r");
	fptr1 =fopen("temp.txt","a");
	fptr2 = fopen("bill.txt","w");
	printf("\t\t\t\t\t**************************************\n");
	printf("\t\t\t\t\t\t\tBILL\n");
	printf("\t\t\t\t\t**************************************\n\n");



	printf("\n\t\t\t\t\tMedicine name : ");
	scanf("%s",name1);
	printf("\t\t\t\t\tQuantity: ");
	scanf("%d",&quantity1);
	printf("\t\t\t\t\tDiscount Percentage: ");
	scanf("%d",&discount);

	while(fscanf(fptr,"%d %s %s %d %d %s ",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
		res=strcmp(name,name1);
		if(res==0)
		{
			valid = 1;
			printf("\n\n|CODE|\t\t  |Item Name|\t\t     |Medicine Company|\t\t   |Quantity|\t|Price|\t\t|Expiry Date|");
			printf("\n---------------------------------------------------------------------------------------------------------------------");
			printf("\n %4d \t %20s \t %30s \t\t %4d \t %4d \t\t %s",code,name,company,quantity,price,expiryDate);
			printf("\n---------------------------------------------------------------------------------------------------------------------");
			quantity2 = quantity-quantity1;
			if(quantity1  > quantity)
			{
				printf("\n\n\n\t\t\t\tThere are not enough medicine left. Would you like to buy %d instead? (Y/N):  ",quantity);
				getchar();

				scanf("%c",&ch);
				if(ch=='y'||ch=='Y'){
                    fprintf(fptr1,"%d\t\t%s\t\t%s\t\t%d\t\t%d\t%s\n",code,name,company,0,price,expiryDate);
                    printf("\n\n\t\t\t\t\t**************************************\n");
                    printf("\t\t\t\t\t\t\tOUTPUT\n");
                    printf("\t\t\t\t\t**************************************\n\n");
                    amount = price * quantity;
                    tempPrice = amount *(discount/100.0);
                    originalPrice = amount - tempPrice;
                    printf("\n\t\t\t\t\t\tQuantity : %d\n",quantity);
                    printf("\t\t\t\t\t\tPrice per item : %d\n",price);
                    printf("\t\t\t\t\t\tAmount : %d\n",amount);
                    printf("\t\t\t\t\t\tDiscount :%d\n",discount);
                    printf("\t\t\t\t\t\tFinal price:%.2f",originalPrice);
                    fprintf(fptr2,"\n\n\t\t\t\t\t**************************************\n");
                    fprintf(fptr2,"\t\t\t\t\t\t\tOUTPUT\n");
                    fprintf(fptr2,"\t\t\t\t\t**************************************\n\n");
                    fprintf(fptr2,"\n\t\t\t\t\t\tQuantity : %d\n",quantity);
                    fprintf(fptr2,"\t\t\t\t\t\tPrice per item : %d\n",price);
                    fprintf(fptr2,"\t\t\t\t\t\tAmount : %d\n",amount);
                    fprintf(fptr2,"\t\t\t\t\t\tDiscount :%d\n",discount);
                    fprintf(fptr2,"\t\t\t\t\t\tFinal price:%.2f",originalPrice);

				}

			}

			else
			{
				fprintf(fptr1,"%d\t\t%s\t\t%s\t\t%d\t\t%d\t%s\n",code,name,company,quantity2,price,expiryDate);
				printf("\n\n\t\t\t\t\t**************************************\n");
                printf("\t\t\t\t\t\t\tOUTPUT\n");
                printf("\t\t\t\t\t**************************************\n\n");
				amount = price * quantity1;
				tempPrice = amount *(discount/100.0);
				originalPrice = amount - tempPrice;
				printf("\n\t\t\t\t\t\tQuantity : %d\n",quantity1);
				printf("\t\t\t\t\t\tPrice per item : %d\n",price);
				printf("\t\t\t\t\t\tAmount : %d\n",amount);
				printf("\t\t\t\t\t\tDiscount :%d\n",discount);
				printf("\t\t\t\t\t\tFinal price:%.2f",originalPrice);
				fprintf(fptr2,"\n\n\t\t\t\t\t**************************************\n");
                fprintf(fptr2,"\t\t\t\t\t\t\tOUTPUT\n");
                fprintf(fptr2,"\t\t\t\t\t**************************************\n\n");
				fprintf(fptr2,"\n\t\t\t\t\t\tQuantity : %d\n",quantity1);
				fprintf(fptr2,"\t\t\t\t\t\tPrice per item : %d\n",price);
				fprintf(fptr2,"\t\t\t\t\t\tAmount : %d\n",amount);
				fprintf(fptr2,"\t\t\t\t\t\tDiscount :%d\n",discount);
				fprintf(fptr2,"\t\t\t\t\t\tFinal price:%.2f",originalPrice);
			}

			fclose(fptr2);
		}
		else
		{
			fprintf(fptr1,"%d\t\t%s\t\t%s\t\t%d\t\t%d\t%s\t",code,name,company,quantity,price,expiryDate);
		}
	}
	if(valid==0)
	{
		printf("\n\n\t\t\t\t\tMedicine not found");
	}
	fclose(fptr);
	fclose(fptr1);

	fptr=fopen("listOfMedicine.txt","w");
	fptr1=fopen("temp.txt","r");
	while(fscanf(fptr1,"%d %s %s %d %d %s\n",&code,name,company,&quantity,&price,expiryDate)!=EOF)
	{
		fprintf(fptr,"\n%d \t %s \t %s \t %d \t %d \t %s",code,name,company,quantity,price,expiryDate);
	}
	fclose(fptr);
	fclose(fptr1);

	remove("temp.txt");
	printf("\n\n------------------------------------------------------------------------------------------------------------------");
	printf("\n\n\tIF you want to purchase more medicine press Y or want to go back to menu press B or press any key to exit : ");
	scanf(" %c",&choice);
	if(choice == 'Y'  || choice == 'y')
	{
		system("cls");
		generateBill();
	}
	else if(choice == 'B' ||choice == 'b')
	{
		system("cls");
        menu();
	}
	else
	{
		system("cls");
		main();
	}
}
