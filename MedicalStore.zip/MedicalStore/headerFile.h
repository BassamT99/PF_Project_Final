void menu();
void addMedicine();
void editMedicine();
void listOfMedicine();
void deleteMedicine();
void searchMedicine();
void generateBill();
void expiryMedicine();
