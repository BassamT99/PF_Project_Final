#include <stdio.h>
#include <time.h>
#include "headerFile.h"

int main()
{
    char userName[10];
    char* name="Admin";
    int password = 12345;
    int userPassword = 0;
    int i = 0;
    int flag = 1;
    int option;


    printf("\n\n\n\n\n\n\n\n\n\n");
    printf("\t\t\t\t\t*****************************************\n");
    printf("\t\t\t\t\t\t\tLOGIN PAGE\n");
    printf("\t\t\t\t\t*****************************************\n");
    printf("\n");
    printf("\n\n\t\t\t\t\t\t    USERNAME : ");
    scanf(" ");
    gets(userName);
    printf(" \n\t\t\t\t\t\t    PASSWORD: ");
    scanf(" %d",&userPassword);
    printf(" \n\n\n\n");

    for(i=0;userName[i]!='\0';i++)
    {
        if(userName[i] == name[i])
        {
        	if(userPassword == password)
	{
		flag=0;
	}
        }
        else
        {
            flag=1;
        }

    }

    if(flag == 0)
    {
        system("cls");
        menu();
    }
    else if(flag==1)
    {
        system("cls");

        main();
    }
    }

